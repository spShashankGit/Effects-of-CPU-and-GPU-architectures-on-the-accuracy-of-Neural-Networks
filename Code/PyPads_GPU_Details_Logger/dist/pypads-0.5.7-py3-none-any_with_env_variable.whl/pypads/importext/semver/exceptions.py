class ParseVersionError(ValueError):
    pass
