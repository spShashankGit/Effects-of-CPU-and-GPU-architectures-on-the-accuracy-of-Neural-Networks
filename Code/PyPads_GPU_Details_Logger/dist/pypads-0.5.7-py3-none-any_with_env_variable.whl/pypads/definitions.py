from pathlib import Path

ROOT_DIR = str(Path(__file__).parent.parent)
